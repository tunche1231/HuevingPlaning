package com.hueving.planner.Actividades;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.hueving.planner.R;

public class PerfilProveedor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_proveedor);
    }
}
